package irb;

public class TestIRB {

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		ClassementIRB cl1 = new ClassementIRB("test1.txt");
		System.out.println(cl1.nbPays());

	}

}
